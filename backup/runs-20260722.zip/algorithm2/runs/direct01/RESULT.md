# RESULT — direct01

## Best feasible design: 50.42 $/tCO2

Membrane CO2 capture plant meeting both hard constraints at minimum cost.
**Both constraints are simultaneously binding** (purity exactly 0.9500, recovery at
the 0.90 floor) — the mathematical signature of a cost-optimal vertex: cost cannot be
reduced further without violating a constraint.

| metric | value | constraint |
|---|---|---|
| CO2 purity | **0.9500** | >= 0.95 ✓ (binding) |
| CO2 recovery | **0.9013** | >= 0.90 ✓ (binding) |
| **cost** | **50.42 $/tCO2** | minimize |
| specific energy | 405.9 kWh/tCO2 | |
| total power | 168.1 MW | |
| total membrane area | 2.15e6 m2 | |
| evaluations used | 51 designs (~2.3 h of 6.5 h budget) | |

Cost breakdown (approx): vacuum-pump capital ~23 + energy ~16 + membrane ~11 $/tCO2.
The cost is vacuum-dominated — an intrinsic feature of vacuum-driven membrane capture
from a dilute (13%) feed.

### Proposal JSON (proposal_51.json, verbatim)

```json
{
  "membranes": {
    "M1": {"area_m2": 820000, "p_permeate_bar": 0.1,  "permeance_gpu": 2500},
    "M2": {"area_m2": 190000, "p_permeate_bar": 0.16, "permeance_gpu": 1900},
    "M3": {"area_m2": 190000, "p_permeate_bar": 0.1,  "permeance_gpu": 6000},
    "M4": {"area_m2": 190000, "p_permeate_bar": 0.1,  "permeance_gpu": 6000},
    "M5": {"area_m2": 190000, "p_permeate_bar": 0.1,  "permeance_gpu": 6000},
    "M6": {"area_m2": 190000, "p_permeate_bar": 0.1,  "permeance_gpu": 6000},
    "M7": {"area_m2": 190000, "p_permeate_bar": 0.1,  "permeance_gpu": 6000},
    "M8": {"area_m2": 190000, "p_permeate_bar": 0.1,  "permeance_gpu": 6000}
  },
  "streams": {
    "feed": "M1",
    "M1.permeate": "M2",   "M1.retentate": "M3",
    "M2.permeate": "product", "M2.retentate": "M1",
    "M3.permeate": "M1",   "M3.retentate": "M4",
    "M4.permeate": "M1",   "M4.retentate": "M5",
    "M5.permeate": "M1",   "M5.retentate": "M6",
    "M6.permeate": "M1",   "M6.retentate": "M7",
    "M7.permeate": "M1",   "M7.retentate": "M8",
    "M8.permeate": "M1",   "M8.retentate": "residue"
  }
}
```

### Robust alternative (proposal_50.json): 50.48 $/tCO2
Identical topology; M2 = 200000 m2 / 1800 GPU. Gives purity 0.9511 and recovery
0.9012 — small **positive** margin on both constraints, for only +0.06 $/tCO2 (+0.1%).
Recommended if any solver/operating tolerance is a concern, since proposal_51 sits
exactly on the purity boundary.

## Flowsheet (why this shape)

```
feed(13% CO2) --> [M1 bulk] --permeate(73%)--> [M2 enrich] --permeate--> PRODUCT (95%)
                     ^  ^                          |
                     |  +--------- M2 retentate ---+
                     |
   [M1 ret 10.8%] -> [M3]->[M4]->[M5]->[M6]->[M7]->[M8] -> RESIDUE (1.5% CO2)
                       all six stripper permeates recycle --> M1
```

- **M1 (bulk):** takes the raw feed plus every recycle, sends a CO2-rich permeate up
  to the product path and a barely-stripped retentate down to the stripping train.
- **M2 (enricher):** lifts M1 permeate (73%) to 95% product; its retentate recycles
  to M1. Runs at moderate selectivity (1900 GPU) tuned so the product lands exactly
  at the 0.95 purity floor (no over-purification cost).
- **M3–M8 (6-stage stripping cascade):** progressively strips the retentate from
  ~10.8% down to 1.5% CO2 to hit 90% recovery. Fed in pure series on the retentate
  (each stays at 1.1 bar, so no extra blowers); all permeates recycle to M1 through
  M1's single blower.

## Design path (77.4 -> 50.4 $/tCO2)

1. **2-stage cascade (prop01):** purity ok-ish but recovery 0.32 — retentate dumped
   straight to residue. Diagnosis: need to strip the retentate.
2. **Add strippers (prop02-06):** each retentate stripper claws back recovery;
   3 strippers reached the first feasible point at **77.4 $/t** (purity 0.968,
   recovery 0.907). Learned the lean tail is *driving-force* limited (needs deep
   vacuum + high permeance), not area limited.
3. **Remove wasted area (prop08-13):** discovered the flowsheet sits on a *plateau* —
   membrane area above a threshold gives byte-identical results. Trimmed every unit to
   its binding area: 77 -> 66 $/t.
4. **High-permeance strippers (prop18-22):** 6000 GPU strips the tail better AND needs
   less area; area savings beat the extra N2-slip energy: 66 -> 61 $/t.
5. **More stripping stages (prop24-31):** 3 -> 6 stages. Each smaller cut yields a
   richer permeate (less N2 pumped) and better staging: 61 -> 52 $/t. Capped at the
   8-membrane limit (M1 + M2 + 6 strippers).
6. **Final trims (prop38-51):** shrank M1 to its threshold (0.82e6) and spent M2's
   purity slack (less-selective M2 landing purity at exactly 0.95): 52 -> **50.42 $/t**.

## Key physics learned this run
- Recovery is set entirely by how lean the last stripper drives the residue; deep
  vacuum (0.10 bar) is mandatory at the lean tail (feed CO2 partial ~ permeate floor).
- High permeance (6000 GPU, low selectivity) is *required* on strippers: at the lean
  tail the CO2 flux = permeance x tiny driving force, so low-permeance membranes stall
  regardless of area.
- M1 wants moderate permeance (2500) and deep vacuum: it must pull CO2 cheaply into a
  rich permeate while leaving a lean-enough retentate for the strippers. More selective
  M1 leaves a richer retentate and overloads the strippers; less selective M1 makes a
  dilute permeate and explodes VP1.
- Cost is vacuum-pump dominated (~39 of 50 $/t). The remaining floor is thermodynamic:
  vacuum work spent co-pumping N2 that finite (Robeson-bounded) selectivity lets slip.
