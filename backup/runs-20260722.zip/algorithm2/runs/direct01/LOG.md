# LOG — direct01

## Eval 1 — proposal_01.json (2-stage cascade w/ recycle)
Params: M1(1.2e6, 0.15, 2000) M2(4e5, 0.25, 1000)
Result: purity 0.877, recovery **0.322**, INFEASIBLE (shortfall 0.65), cost 44.1 $/t (n/a), spec E 228 kWh/t
Streams: M1.perm 55.5%CO2/4476; M1.ret->residue 9.25%CO2/**7074** (68% of feed CO2 lost!); M2.perm->product 87.7%/3366.
Energy: VP1 19.1MW (dominant), VP2 6.1, COMP1 7.8, COMP2 0.8.
Diagnosis: (a) recovery killed by unstripped M1 retentate; (b) purity short (need M2 richer feed / higher selectivity).
Action: add retentate stripper M3 (permeate recycled), 3-stage cascade.

## Eval 3 — proposal_02.json (3-stage: +stripper M3)
purity 0.958 (MET), recovery 0.622, cost 50.4. Residue 3947 CO2@5.4%. Stripper works but under-strips. Energy VP3 35MW.

## Eval 4 — proposal_03.json (4-stage: 2 strippers @1e6/3500)
purity 0.970, recovery 0.805. Residue 2040@2.85%. Energy 146MW (VP3 46). Diminishing tail.

## Eval 5 — proposal_04.json (strippers permeance 1500)
purity 0.960, recovery 0.657 (DROP). Low permeance starves stripper flux. Energy 90MW (less N2 slip). Lesson: recovery needs stripper flux.

## Eval 6 — proposal_05.json (strippers @1.5e6/3500, M1 deeper 0.10)
purity 0.965, recovery 0.838. Residue 1697@2.4%. Energy 154MW. 1e6->1.5e6 barely helped (0.805->0.838): TAIL IS DRIVING-FORCE LIMITED not area.

## Eval 7 — proposal_06.json (5-stage: 3 strippers @1.5e6/3500) *** FIRST FEASIBLE ***
purity 0.968, recovery 0.907, FEASIBLE, cost **77.41**, specE 458, power 191MW.
Cost split ~ membrane 33 + machine(VP) 25.5 + energy 18.3 $/t. M1 processes 121,600 kmol/h (recycle explosion). VP1 51MW.

## Eval 8 — proposal_07.json (counter-current cascade permeate routing)
WORSE: cost 84.5, recovery 0.877, power 213MW. Routing permeates into strippers spawns extra blowers (COMP3/4). Keep all-permeates->M1 (single blower) topology.

## Evals 9-16 — AREA & PERMEANCE optimization (topology fixed = prop06)
KEY: system sits on a PLATEAU — area above a threshold gives byte-identical streams (wasted $).
- prop08 strippers 1.2e6: identical to 1.5e6, cost 77->72.8
- prop10 strippers 1.0e6: identical, 69.7. prop11 0.85e6: rec 0.891 (below plateau).
- prop12 M1 1.2e6: identical, 68.1. prop13 M1 0.9e6: rec 0.9036, **66.48** (M1 threshold ~0.9e6).
- prop14 strippers 1500/1.5e6: energy 190->115MW (less N2 slip!) BUT rec 0.776 — low permeance flux dies at lean tail.
- prop15 strippers 2500/1.5e6: rec 0.859. CONFIRMED deep stripping needs HIGH permeance (3500) for tail flux, not area.
- prop16 M2 perm 0.25: VP2 21.5->15.4 but recycle up, rec 0.9003, cost 66.26 (thin margin).
STATE: best ~66.3, recovery-constrained. Vacuum (VP cap 25 + energy 18 = 43 $/t) >> membrane 22. Every energy cut breaks recovery.

## Evals 17-51 — DESCENT to optimum (topology: M1 bulk + M2 enrich + 6 strippers, all perm->M1)
- STAGING WIN: 3->4->5->6 strippers each cut cost (better staging = richer per-stage permeate = less N2 slip + less area). 6 strippers @ high permeance(6000)/deep vac(0.10) optimal. (61->56->53->52)
- Stripper permeance: HIGH (6000) needed for lean-tail flux; smaller area suffices. Distribution among strippers irrelevant (only total ~1.14e6 matters).
- M1 permeance sweet spot = 2500 (1800 overloads strippers->recovery drops; 3500 leaner permeate->VP1 explodes). M1 deep vac 0.10 optimal (captures CO2 cheaply into rich permeate).
- M1 area threshold ~0.82e6 (6 strippers absorb load). Buying recovery margin via bigger strippers costs ~1.3$/t per +0.007 rec.
- M2: exploit purity slack -> less selective/smaller M2 (1900GPU/0.19e6) lands purity exactly 0.9500.
- Rejected: graded vacuum (shifts work downstream), M2-retentate->stripper (collapses recovery), M2 high permeate pressure (VP2 down but VP1 recycle up, ~neutral).

## FINAL OPTIMUM — proposal_51.json (eval #53): cost **50.42 $/tCO2**
purity 0.9500, recovery 0.9013 — BOTH constraints binding (cost-optimal vertex). specE 406, power 168MW.
Cost split: membrane ~11, energy ~16, vacuum-pump capital ~23 $/t. Down from first-feasible 77.4 (-35%).
Robust alt: proposal_50.json 50.48$/t (purity 0.9511, recovery 0.9012 — positive margin both).
