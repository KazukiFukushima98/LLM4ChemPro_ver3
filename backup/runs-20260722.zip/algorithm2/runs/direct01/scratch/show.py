import json, sys
f = sys.argv[1]
txt = open(f).read()
d = json.loads(txt[:txt.rfind('}')+1])
print(f"STATUS {d.get('status')}  purity {d['CO2_purity']:.4f}  recovery {d['CO2_recovery']:.4f}  FEASIBLE {d['feasible']}  cost {d['cost_usd_per_tCO2']:.2f}  specE {d['specific_energy_kWh_per_tCO2']:.1f}")
if 'energy_breakdown_kW' in d:
    tot = sum(d['energy_breakdown_kW'].values())
    print("  energy kW:", {k: round(v) for k, v in d['energy_breakdown_kW'].items()}, "TOTAL", round(tot))
for k, v in d['streams'].items():
    desc = v['description']
    if k in ('V1', 'V2') or 'retentate' in desc or 'permeate' in desc:
        print(f"  {k:4} {v['CO2_molfrac']:.4f}  CO2={v['CO2_moleflow']:9.1f}  tot~{v['CO2_moleflow']/max(v['CO2_molfrac'],1e-9):9.0f}  {desc}")
