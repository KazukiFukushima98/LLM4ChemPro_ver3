# Design reasoning — direct01

## Feed / targets
- Feed 80,307 kmol/h, 13% CO2 -> CO2 = 10,440 kmol/h, N2 = 69,867 kmol/h, 1.0 bar
- Feed membrane boosted to 1.1 bar (blower, auto). Permeate vacuum in [0.1,0.99].
- Need purity>=0.95, recovery>=0.90; min $/tCO2.

## Product spec implication
- Recovery 0.90 -> product CO2 >= 9,396 kmol/h
- Purity 0.95 -> product N2 <= 9,396*(0.05/0.95) = 494 kmol/h
- Product ~ 9,396 CO2 + <=494 N2 ~ 9,890 kmol/h
- Residue ~ 69,373 N2 + 1,044 CO2 ~ 1.5% CO2

## Physics
- Feed-side CO2 partial pressure (stage1) = 1.1*0.13 = 0.143 bar = 14,300 Pa. Small driving force -> big area, deep vacuum.
- To get permeate 40% CO2 at stage1: p_perm*0.40 < 0.143 -> p_perm < 0.36 bar
- Robeson: low permeance (500 GPU) alpha~99 (selective), high permeance (6000) alpha~43 (flux).
- Cost tradeoff: area (50 $/m2 capital) vs vacuum energy (1341 $/kW + electricity). Single dilute feed => classic hard case.

## Area estimate (M1)
- 1 GPU = 3.35e-10 mol/(m2 s Pa). 2000 GPU = 6.7e-7.
- CO2 flux ~ permeance*Δp_CO2; Δp~8000 Pa -> flux ~5.4e-3 mol/(m2 s)
- Need ~2611 mol/s CO2 to permeate -> area ~4.8e5 m2 minimum for M1.

## Proposal 01: 2-stage cascade with recycle (PROBLEM example wiring)
- M1 bulk: large area, deep vacuum, mid permeance (selectivity ~65)
- M2 enrich: smaller area, higher selectivity (permeance ~1000)
- feed->M1; M1.perm->M2; M1.ret->residue; M2.perm->product; M2.ret->M1(recycle)
