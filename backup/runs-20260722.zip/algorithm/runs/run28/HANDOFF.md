# run28 HANDOFF

**Stopped: explicit stop instruction from the user** (2026-07-16), after 3 iterations.
This was **not** a convergence stop and **not** a failure stop — the shortfall was still
improving monotonically at every iteration (0.429 -> 0.0486 -> 0.0327). The loop was
interrupted mid-analysis, before the iter_003 -> iter_004 `ss_change.json` was written.
`runs/run28/iterations/iter_003/ss_change.json` does **not** exist; iter_003 is the last
iteration and its results are complete.

## Setup

- Seed: `ss_seed.json` verbatim (2-stage blower/vacuum cascade), feed 13 mol% CO2,
  80307 kmol/h, blower campaign (COMP fixed at 1.1 bar per type, no GA variable).
- `case.yaml`: objective=minimize_cost, purity_min=0.95, recovery_min=0.90,
  optimizer=bo (n_init=24, n_iter=60, q_batch=4, patience=10).
- Production run throughout (no `--dry`), auto-commit left to `run_iteration.py`.

## Final performance (iter_003, the authoritative `results.json`)

| metric | value | target | status |
|---|---|---|---|
| CO2_purity | **0.956992626** | >= 0.95 | **MET** |
| CO2_recovery | **0.867327250** | >= 0.90 | short by 0.0327 |
| cost_usd_per_tCO2 | 70.4065 | (minimise) | not yet the criterion |
| specific_energy_kWh_tCO2 | 539.899 | (reference) | |
| total_compressor_kW | 215102.2 | | |

Trajectory (criterion = total shortfall, since the constraints are unmet):

| iter | purity | recovery | shortfall | cost $/tCO2 | note |
|---|---|---|---|---|---|
| 001 | 0.9080 | 0.5134 | 0.429 | 53.74 | baseline, 0 binaries |
| 002 | 0.9462 | 0.8552 | 0.0486 | 67.72 | +3rd stage (gated) +V6 recycle: both adopted |
| 003 | 0.9570 | 0.8673 | 0.0327 | 70.41 | purity MET; polish stage adopted, 4th stage rejected |

Note the cost rises monotonically as the shortfall falls — recovery is being bought with
vacuum power. Once recovery is feasible, expect the cost criterion to fight back hard.

## Final structure (`ss_current.json`, iteration=2 header, as run in iter_003)

Units: COMP1, COMP2, MEMB1, MEMB2, COMP3, MEMB3, COMP4, MEMB4, COMP5, MEMB5.
Binaries (4): q_5, q_6 (COMP4/MEMB4 gate pair), q_7, q_8 (COMP5/MEMB5 gate pair).
Continuous (15): area / p_perm / perm for MEMB1..MEMB5.

Fixed by `promote_candidate` in the iter_002 transition (both were ON in the iter_002 best):
- MEMB3 feed (V3 -> V13): the 3rd stage on the MEMB1 retentate, permeate recycled to V9.
- V6 -> V9: the MEMB2 retentate recycle.

As resolved by the optimiser in iter_003 (`active_candidates`):
- q_7=1 / q_8=0 -> **product-side polishing stage MEMB5 ADOPTED**. This is what closed the
  purity constraint (0.9462 -> 0.9570). Side effect worth noting: it freed MEMB2 off its
  selectivity bound (MEMB2_perm 1.3534 -> 6.6898, i.e. 500 -> 2471 GPU) and let MEMB2_area
  fall 1.005e6 -> 4.47e5. The polish stage does the purity job more cheaply than a
  max-selectivity MEMB2 did.
- q_5=0 / q_6=1 -> **4th retentate stage MEMB4 REJECTED** (pruned; it has no entry in
  `optimal_params` and no VP4/COMP4 in `energy_breakdown`).

## Why recovery is stuck at 0.867 — the open question

The CO2 balance is now down to a single leak. Feed 10439.9 kmol/h CO2 ->
product V7 9054.8 (86.7%) + residue V8/V16 1385.7 (13.3%). There is no other loss.
That residue is the **MEMB3 retentate at just 1.96% CO2**, and its total flow is ~70700
kmol/h (it carries essentially all the N2). To reach recovery 0.90 the residue CO2 must
fall below ~1044 kmol/h, i.e. x_res ~ 1.48%.

**My unverified hypothesis (this is what I was checking when the loop was stopped):**
the deep-strip end of MEMB3 is **pressure-ratio limited, not area limited**, and 0.90
recovery may be thermodynamically out of reach for this campaign's architecture.
Reasoning: the blower fixes the feed at 1.1 bar and `p_permeate` has a hard floor of 0.1 bar,
so the pressure ratio is capped at 11. The local permeate composition cannot exceed
x * (p_ret/p_perm) = 11x, at which point the driving force is zero. At x=1.96% that
ceiling is y<=0.216, and MEMB3's actual bulk permeate is already 0.168 — close to it.
If that reading is right, stripping stalls asymptotically and no amount of extra
retentate-side area buys the last 0.033 of recovery.

**Supporting evidence:** MEMB3_area=1.004e6 has ~0.5e6 of unused headroom below its 1.5e6
cap and the optimiser declined to use it — consistent with "more area at the strip end is
worthless", not with "area-limited". And MEMB4, which is exactly "more strip-end area in
series", was rejected outright.

**This hypothesis is NOT confirmed.** It is arithmetic on the returned `results.json`
numbers plus a textbook pressure-ratio argument; it has not been tested. Confirming or
refuting it is the single most valuable next step, and it wants a human / development
session (isolating it inside the autonomous loop would be a probe, which is forbidden).

## What I would do next

1. **Settle the pressure-ratio question first** — everything else depends on it.
   If confirmed, then under the blower campaign recovery_min=0.90 is infeasible by
   construction, and that is a finding about the campaign definition, not a failure of the
   search. The options then are human decisions: relax recovery_min, lower the
   `permeance_bounds`/`p_permeate` floor below 0.1 bar, or admit a real compressor
   (>1.1 bar) on the strip stage — all of which are fixed settings the agent must not touch.
2. **If it is refuted**, the transition I had drafted (not written to disk) was:
   - `promote_candidate q_7` + `delete_arc V5->V7` (fix the polishing stage; it is ON and it
     is what meets purity), and
   - **give MEMB4 a fair second chance by rewiring its permeate**: `delete_arc V19->V9` +
     `add_arc V19->V13` (fixed). Rationale for the rejection: MEMB4's permeate was being
     recycled to V9, which loads MEMB1 — and **MEMB1 is the area-capped bottleneck**
     (MEMB1_area=1.421e6 = 94.7% of the 1.5e6 cap, MEMB1_perm pinned at the 6000 GPU
     upper bound). So MEMB4 ON very plausibly made things *worse* via that feedback, and
     it was never evaluated in a form that avoids MEMB1. Returning its permeate to V13
     (the MEMB3 inlet, a sanctioned pre-mixer position, in-degree 2 = Mixer, out-degree 1)
     keeps the strip loop local. Binaries would go 4 -> 2.
   - Caveat on this plan: MEMB4 was rejected in a d=19 BO (24 init) that early-stopped at
     patience=10 while still in the bootstrap phase. Under-exploration is a live
     alternative explanation for the rejection — it is not proven that MEMB4 is bad.

## Signals to watch

- **MEMB1_area = 1.421e6 / 1.5e6 cap (94.7%) with MEMB1_perm pinned at the 6000 GPU upper
  bound.** MEMB1 wants maximum flux and more area than one unit is allowed. There is no
  structural workaround available: a parallel membrane is not expressible (the builder has
  no splitter, and out-degree <= 1 holds outside membrane inlets), so the only route is
  series staging on its retentate — which is what MEMB3 already is.
- **The bulk/polish specialisation is real and stable**: MEMB1 and MEMB3 both pin at the
  6000 GPU *upper* permeance bound (max flux, alpha~43, bulk removal); the purity stage pins
  low (max Robeson selectivity). After MEMB5 took over polishing, MEMB2 stopped pinning
  altogether. Watch whether MEMB5 keeps pinning — in iter_003 MEMB5_p_perm=0.3054 and
  MEMB5_perm=2.4338 were the **first non-pinned** membrane variables in the whole run.
- **Vacuum dominates the cost.** VP1 86982 + VP2 36568 + VP3 63576 + VP5 12639 = 199765 kW
  of the 215102 kW total (93%); COMP1+COMP2+COMP5 = 15337 kW (7%). All of MEMB1/2/3_p_perm
  pin at the 0.1 bar floor. The cost fight, once recovery is feasible, is entirely a
  vacuum-depth fight.

## Bug found during this run (needs a development session — outside `runs/`)

`algorithm/src/simulator.py` `_build` (line 225) has **inconsistent return arity**: the
success path returns a 3-tuple `(aspen, energy_blocks, coolers)` (line 268) but both
failure paths return 2-tuples `return None, None` (lines 239, 244). All three call sites
unpack 3 values (lines 391, 426, 451). So a legitimate Aspen build failure raises
`ValueError: not enough values to unpack (expected 3, got 2)` and **kills the entire
evaluation batch** (observed in `iter_003_log.txt`: `[subprocess] wedged=False rc=1
missing=4/4`) instead of being handled as a single BAD topology.

It is currently **masked** by the retry mechanism (`[CBO] retry recovered 4/4 bad eval(s)
(transient wedge)`) — it hit once in iter_003 and the batch was recovered — but it is
misclassified: this is a *deterministic* build failure being retried as if it were a
transient wedge, at the cost of a full batch re-evaluation each time. Almost certainly
introduced by the 2026-07-16 HX cost change, which added `coolers` to the success return
and to the call sites but not to the two failure returns; the docstring at line 226 is
still stale ("Returns (None, None) on failure").

Fix: return `None, None, None` from both failure paths, update the docstring, and consider
distinguishing a deterministic build failure from a transient wedge in the retry logic.
`iter_003`'s results should be treated as sound — the one occurrence was recovered — but
any run with many build failures would be silently and expensively degraded.
