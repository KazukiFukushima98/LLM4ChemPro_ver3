# run30 HANDOFF

**Campaign**: blower + vacuum driven (COMP fixed at 1.1 bar per type), objective = minimize capture cost.
**Feed**: co2_frac=0.13 (first run at the new 0.13; run24–26 used 0.15), 80,307 kmol/h.
**Targets**: purity ≥ 0.95, recovery ≥ 0.90.

## Outcome: FEASIBLE. Converged (cost floor).

Starting from the 2-stage seed, the SST discovered a **feasible 4-stage membrane cascade** and then
converged in the cost-minimisation phase (no improvement of the best feasible cost for 3 consecutive
iterations).

### Best feasible point — iter_005
| Metric | Value |
|---|---|
| CO2 purity | **95.14 %** (≥ 0.95 ✓) |
| CO2 recovery | **90.15 %** (≥ 0.90 ✓) |
| **Capture cost** | **67.15 $/tCO2** |
| Specific energy | 530 kWh/tCO2 |

Iterations 006–008 re-ran the same locked structure and landed at 74.60 / 69.23 / 72.05 $/tCO2 — the
67–75 $/tCO2 spread is **BO seed variance around an intrinsic vacuum-work floor**, not a structural
difference. 67.15 was the low end of that band.

## Final structure (4-stage cascade, 0 binaries, 12 continuous)

- **MEMB1** (bulk): feed + all recycles (mixer V9) → COMP1 (1.1 bar) → permeate V2 → MEMB2;
  retentate V3 → MEMB3.
- **MEMB2** (enrich): V2 → COMP2 (1.1 bar) → permeate V5 = **product** (0.95+); retentate V6 → recycle to V9.
- **MEMB3** (strip): MEMB1 retentate V3 → permeate V14 → recycle to V9; retentate V15 → MEMB4.
- **MEMB4** (deep strip): V15 → permeate V17 → recycle to V9; retentate V18 → **residue** (only N2 exit).

All three recycles (V6, V14, V17) join the feed pre-mixer V9. MEMB3+MEMB4 are the stripping section that
lifts recovery from ~0.85 (3-stage ceiling) to ≥ 0.90.

## Iteration log
| iter | move | purity | recovery | cost $/tCO2 | shortfall |
|---|---|---|---|---|---|
| 001 | baseline seed (2-stage) | 90.8 % | 51.1 % | 56.1 | 0.431 |
| 002 | 2 residue-vs-recycle toggle pairs (V3, V6) | 92.9 % | 66.0 % | 53.5 | 0.261 |
| 003 | +MEMB3 gated strip on V3 | 94.9 % | 85.4 % | 67.0 | 0.047 |
| 004 | lock winning candidates (0 binaries) | 94.6 % | 85.5 % | 66.4 | 0.049 |
| 005 | +MEMB4 gated deep-strip on V15 | **95.1 %** | **90.2 %** | **67.2** | **0 (feasible)** |
| 006 | lock MEMB4 (cost-min) | 96.0 % | 91.4 % | 74.6 | feasible |
| 007 | V6 routing toggle (V9 vs V11 reflux) | 95.9 % | 90.8 % | 69.2 | feasible |
| 008 | consolidate (V6→V9 fixed), confirm | 96.2 % | 91.0 % | 72.1 | feasible |

Iterations run: **8** (001 baseline + 7 structural moves; 005–008 feasible).

## Why stopped
Both constraints met from iter_005. On the cost criterion (`cost_usd_per_tCO2`), the best feasible cost
(67.15, iter_005) did **not** improve for 3 consecutive iterations (006/007/008). Structural cost levers
are exhausted:
- All 4 stages are load-bearing — MEMB1 (bulk), MEMB2 (purity), MEMB3+MEMB4 (the deep strip required to
  cross recovery 0.90). Removing any breaks feasibility.
- The one rerouting option tried (V6 enriching reflux to V11) was **rejected by BO** (q_10=0) — sending V6
  back through MEMB1 is genuinely cheaper.

## Cost anatomy (iter_005 feasible point)
Permeate-side vacuum pumps dominate (~87 % of ~219 MW): VP3 ≈ 73 MW, VP1 ≈ 68 MW, VP4 ≈ 50 MW, VP2 ≈ 14 MW;
COMP1 ≈ 12 MW, COMP2 ≈ 2 MW. Driven by the heavy recycle (MEMB1 inlet throughput ≈ 132,000 vs 80,307 kmol/h
feed). This is the structural cost of reaching 90 % recovery from 13 % CO2 with only 1.1-bar driving force.

## What I would do next
1. **BO reproducibility of the cost.** The 67–75 $/tCO2 spread on an identical locked structure is large.
   The cheapest feasible point (iter_005) ran with the smallest MEMB1_area (680k) and near-binding recovery
   (0.9015); the expensive runs over-satisfied recovery with MEMB1_area near the 1.5e6 cap. Consider a
   larger `bo.n_init` / longer `n_iter`, or a cost-margin-aware acquisition, so the CEI phase reliably
   settles at the near-binding (cheapest) feasible point instead of sampling the expensive high-margin band.
   *(Human/dev decision — not something the autonomous loop can change: `case.yaml` is human-managed.)*
2. **Campaign question for the human.** Cost is floored by vacuum work under the 1.1-bar cap. If a modest
   feed compression (e.g. 2 bar) were allowed, the driving force would rise and recovery-90 % would need far
   less recycle/vacuum — likely a large cost drop. This is a campaign-level change, out of scope for the
   autonomous loop.

## Signals to watch on any restart
- **MEMB1_area near the 1.5e6 cap** in a feasible point ⇒ BO chose an expensive high-margin regime; the
  cheaper optimum has a much smaller MEMB1 and near-binding recovery.
- **All p_perm pinned at 0.1** (max vacuum) — expected/optimal; don't misread as a bounds problem to widen.
- **Residue = MEMB4 retentate V18** is the only N2 exit; recovery = 1 − (V18 CO2)/(feed CO2). Watch V18 CO2.
